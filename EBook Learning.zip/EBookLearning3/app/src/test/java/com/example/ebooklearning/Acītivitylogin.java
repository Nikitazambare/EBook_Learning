package com.example.ebooklearning;

public interface Acītivitylogin {
}
