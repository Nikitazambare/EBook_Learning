package com.example.ebooklearning;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthException;

public class Activity_Login extends AppCompatActivity {
    EditText User;
    EditText Pass;
    Button Login;
    DBHelper DB;
    FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        User = findViewById(R.id.User);
        Pass = findViewById(R.id.Pass);
        Login = findViewById(R.id.Loginbutton);
        DB = new DBHelper( this);
        auth = FirebaseAuth.getInstance();

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = User.getText().toString();
                String pass = Pass.getText().toString();

                if (user.equals("") || pass.equals(""))
                    Toast.makeText(Activity_Login.this, "Please enter all the Fields", Toast.LENGTH_SHORT).show();
                else {
                    Boolean checkuserpass = DB.checkusernamepassword(user, pass);
                    if (checkuserpass == true) {
                        Toast.makeText(Activity_Login.this, "Login Successfully", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent( getApplicationContext() , Activity_Medium.class);
                        startActivity(intent);
                    } else {
                        Toast.makeText(Activity_Login.this, "Invalid Candidate", Toast.LENGTH_SHORT).show();
                    }
                }

                Intent intent = new Intent( Activity_Login.this , Activity_Medium.class);
                startActivity(intent);

            }

        });

    }
}